import base64
import traceback
import mysql.connector
from PyQt6.QtGui import QPixmap
from PyQt6.QtWidgets import QTableWidget, QFileDialog, QMessageBox, QTableWidgetItem
from MainWindow import Ui_MainWindow

import os


class MainWindowEx(Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.default_avatar = "./image/ic_no_avatar.png"

        self.id=None
        self.code=None
        self.name=None
        self.age=None
        self.avatar=None
        self.intro=None

    def setupUi(self,MainWindow):
        """Override phương thức setupUI"""
        super().setupUi(MainWindow)
        self.MainWindow = MainWindow
        self.tableWidgetStudent.itemSelectionChanged.connect(self.processItemSelection)
        self.pushButtonAvatar.clicked.connect(self.pickAvatar)
        self.pushButtonRemoveAvatar.clicked.connect(self.removeAvatar)
        self.pushButtonInsert.clicked.connect(self.processInsert)
        self.pushButtonUpdate.clicked.connect(self.processUpdate)
        self.pushButtonRemove.clicked.connect(self.processRemove)
        self.pushButtonNew.clicked.connect(self.clearData)
    def show(self):
        self.MainWindow.show()

    def connectMySQL(self):
        """ kết nối MySQL Server, cơ sở dữ liệu"""
        server = 'localhost'
        port = 3306
        database = 'studentmanagement'
        username = 'root'
        password = 'carot'

        try:
            self.conn = mysql.connector.connect(
                host=server,
                port=port,
                database=database,
                user=username,
                password=password
            )
        except mysql.connector.Error as e:
            self.conn = None

    def selectAllStudent(self):
        cursor = self.conn.cursor(buffered=True)
            # query all students
        sql = "select * from student"
        cursor.execute(sql)
        dataset = cursor.fetchall()
        self.tableWidgetStudent.setRowCount(0)
        row=0
        for item in dataset:
            row = self.tableWidgetStudent.rowCount()
            self.tableWidgetStudent.insertRow(row)

            self.id = item[0]
            self.code = item[1]
            self.name = item[2]
            self.age = item[3]
            self.avatar = item[4]
            self.intro = item[5]
            self.tableWidgetStudent.setItem(row, 0, QTableWidgetItem(str(self.id)))
            self.tableWidgetStudent.setItem(row, 1, QTableWidgetItem(self.code))
            self.tableWidgetStudent.setItem(row, 2, QTableWidgetItem(self.name))
            self.tableWidgetStudent.setItem(row, 3, QTableWidgetItem(str(self.age)))
        cursor.close()

    def processItemSelection(self):
        """hiển thị thông tin chi tiết student khi nhấn vào từng dòng dữ liệu trong QTableWidget"""
        row=self.tableWidgetStudent.currentRow()
        if row==-1:
            return
        try:
            code=self.tableWidgetStudent.item(row,1).text()
            cursor=self.conn.cursor()
            sql = 'select * from student where code=%s'
            val=(code,)
            cursor.execute(sql,val)
            item=cursor.fetchone()
            cursor.fetchall()
            cursor.close()
            if item != None:
                self.id= item[0]
                self.code = item[1]
                self.name = item[2]
                self.age = item[3]
                self.avatar = item[4]
                self.intro = item[5]
                self.lineEditId.setText(str(self.id))
                self.lineEditCode.setText(self.code)
                self.lineEditName.setText(self.name)
                self.lineEditAge.setText(str(self.age))
                self.lineEditIntro.setText(self.intro)
                if self.avatar != None:
                    imgdata = base64.b64decode(self.avatar)
                    pixmap = QPixmap()
                    pixmap.loadFromData(imgdata)
                    self.label_7.setPixmap(pixmap)
                else:
                    pixmap = QPixmap(self.default_avatar)
                    self.label_7.setPixmap(pixmap)
            else:
                print("Not Found")
        except:
            traceback.print_exc()

    def pickAvatar(self):
        filters = "Picture PNG (*.png);;All files(*)"
        filename, selected_filter = QFileDialog.getOpenFileName(
            self.MainWindow,
            filter=filters,
        )
        if filename == '':
            return
        pixmap = QPixmap(filename)
        self.label_7.setPixmap(pixmap)
        with open(filename, "rb") as image_file:
            self.avatar = base64.b64encode(image_file.read())
            print(self.avatar)
        pass

    def removeAvatar(self):
        self.avatar = None
        print("Avatar path:", os.path.exists(self.default_avatar), self.default_avatar)
        pixmap = QPixmap(self.default_avatar)
        self.label_7.setPixmap(pixmap)

    def processInsert(self):
        try:
            while self.conn.unread_result:
                self.conn.get_rows()
            cursor = self.conn.cursor(buffered=True)
            sql = 'insert into student(Code,Name,Age,Avatar,Intro) values(%s,%s,%s,%s,%s)'
            self.code = self.lineEditCode.text()
            self.name = self.lineEditName.text()
            self.age = int(self.lineEditAge.text()) if self.lineEditAge.text() else None
            intro = self.lineEditIntro.text()
            avatar_data = self.avatar if self.avatar else None
            val = (self.code, self.name, self.age, avatar_data, intro)
            cursor.execute(sql, val)
            self.conn.commit()
            print(cursor.rowcount, 'record inserted.')
            self.lineEditId.setText(str(cursor.lastrowid))
            cursor.close()
            self.selectAllStudent()
        except Exception:
            traceback.print_exc()

    def processUpdate(self):
        try:
            while self.conn.unread_result:
                self.conn.get_rows()
            cursor = self.conn.cursor(buffered=True)
            sql = 'update student set Code=%s, Name=%s, Age=%s, Avatar=%s, Intro=%s where Id=%s'
            self.id = int(self.lineEditId.text())
            self.code = self.lineEditCode.text()
            self.name = self.lineEditName.text()
            self.age = int(self.lineEditAge.text())
            if not hasattr(self, 'avatar'):
                self.avatar = None
            self.intro = self.lineEditIntro.text()
            val = (self.code, self.name, self.age, self.avatar, self.intro, self.id)
            cursor.execute(sql, val)
            self.conn.commit()
            print(cursor.rowcount, 'record updated.')
            cursor.close()
            self.selectAllStudent()
        except Exception:
            traceback.print_exc()

    def processRemove(self):
        try:
            dlg = QMessageBox(self.MainWindow)
            dlg.setWindowTitle("Xác nhận xóa")
            dlg.setText("Bạn có chắc chắn muốn xóa sinh viên này không?")
            dlg.setIcon(QMessageBox.Icon.Question)

            dlg.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            button = dlg.exec()
            if button == QMessageBox.StandardButton.No:
                return
            while self.conn.unread_result:
                self.conn.get_rows()
            cursor = self.conn.cursor(buffered=True)
            sql = 'delete from student where Id=%s'
            val = (self.lineEditId.text(),)
            cursor.execute(sql, val)
            self.conn.commit()
            print(cursor.rowcount, 'record removed')
            cursor.close()
            self.selectAllStudent()
            self.clearData()
        except Exception:
            traceback.print_exc()

    def clearData(self):
        self.lineEditId.setText("")
        self.lineEditCode.setText("")
        self.lineEditName.setText("")
        self.lineEditAge.setText("")
        self.lineEditIntro.setText("")
        self.avatar = None
        self.label_7.setPixmap(QPixmap(self.default_avatar))
