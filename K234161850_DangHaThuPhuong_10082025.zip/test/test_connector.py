import traceback
import mysql.connector

server = 'localhost'
port = 3306
database = 'k23416_retail'
username = 'root'
password = 'carot'

try:
    conn = mysql.connector.connect(
        host = server,
        port = port,
        database = database,
        user = username,
        password = password
    )
except:
    traceback.print_exc()
print('--CONTINUE--')
print("--CRUD--")

# Câu 1: Đăng nhập cho Customer
def login_customer(email, pwd):
    cursor = conn.cursor()
    sql = "select * from customer " \
          "where Email = '" + email + "' and Password = '" + pwd + "'"
    cursor.execute(sql)
    dataset = cursor.fetchone()
    if dataset != None:
        print(dataset)
    else:
        print('Login failed')
    cursor.close()
login_customer('hocamdao@gmail.com', '123')

def login_employee(email, pwd):
    cursor = conn.cursor()
    sql = "select * from employee "\
            "where Email = %s and Password = %s"
    val = (email, pwd)
#     1 doi so: val = (email,) phai co dau ,
    cursor.execute(sql, val)
    dataset = cursor.fetchone()
    if dataset != None:
        print(dataset)
    else:
        print('Login failed')
    cursor.close()
login_employee('kimunun@gmail.com', '123')






