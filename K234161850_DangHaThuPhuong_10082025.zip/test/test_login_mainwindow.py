from PyQt6.QtWidgets import QMainWindow, QApplication

from retail_project.uis.LogInMainWindowEx import LogInMainWindowEx

app=QApplication([])
login_ui=LogInMainWindowEx()
login_ui.setupUi(QMainWindow())
login_ui.showWindow()
app.exec()