from PyQt6.QtWidgets import QMessageBox, QMainWindow
from retail_project.connectors.employee_connector import EmployeeConnector
from retail_project.uis.LogInMainWindow import  Ui_MainWindow


class LogInMainWindowEx(Ui_MainWindow):
    def __init__(self):
        pass

    def setupUi(self, MainWindow):
        super().setupUi(MainWindow)
        self.MainWindow = MainWindow
        self.setupSignalAndSlot()

    def showWindow(self):
        self.MainWindow.show()
    def setupSignalAndSlot(self):
        self.pushButtonLogin.clicked.connect(self.process_login)
    def process_login(self):
        email=self.lineEdit.text()
        pwd=self.lineEditPassword.text()
        ec = EmployeeConnector()
        ec.connect()
        em = ec.login(email, pwd)
        if em == None:
           msg=QMessageBox()
           msg.setIcon(QMessageBox.Icon.Critical)
           msg.setText("Login Failed Check your account again")
           msg.setWindowTitle("Login Failed")
           msg.setStandardButtons(QMessageBox.StandardButton.Ok)
           msg.exec()
        else:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Icon.Information)
            msg.setText("Congratulations, you are logged in")
            msg.setWindowTitle("Login")
            msg.setStandardButtons(QMessageBox.StandardButton.Ok)
            msg.exec()